package com.example.asteroidradar

import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET

object Constants {
    const val API_QUERY_DATE_FORMAT = "YYYY-MM-dd"
    const val DEFAULT_END_DATE_DAYS = 7
    const val BASE_URL = "https://api.nasa.gov/"
    const val API_KEY = "OEhrGMe8Q5o7DATRan1cc3oJy51RxYy1ljLputGc"
    const val IMAGE_MEDIA_TYPE = "image"
    const val REFRESH_ASTEROIDS_WORK_NAME = "AsteroidRefreshDataWorker"
    const val DELETE_ASTEROIDS_WORK_NAME = "AsteroidDeleteDataWorker"

}
