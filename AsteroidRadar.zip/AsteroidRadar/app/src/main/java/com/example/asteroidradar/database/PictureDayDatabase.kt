package com.example.asteroidradar.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.asteroidradar.PictureOfDay
import com.example.asteroidradar.database.PictureDayDao


@Database(entities = [PictureOfDay::class], version = 1)
abstract class PictureDayDatabase : RoomDatabase()  {
    abstract fun pictureDayDatabase(): PictureDayDao
}