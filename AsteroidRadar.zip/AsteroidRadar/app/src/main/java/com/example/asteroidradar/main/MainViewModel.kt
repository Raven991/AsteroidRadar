package com.example.asteroidradar.main

import android.app.Application
import androidx.lifecycle.*
import com.example.asteroidradar.Asteroid
import com.example.asteroidradar.Constants.IMAGE_MEDIA_TYPE
import com.example.asteroidradar.PictureOfDay
import com.example.asteroidradar.api.Network
import com.example.asteroidradar.database.PictureDayDao
import com.udacity.asteroidradar.api.getSeventhDay
import com.udacity.asteroidradar.api.getToday
import com.udacity.asteroidradar.database.AsteroidDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AsteroidDatabase.getDatabase(application)
    private val asteroidRepository = AsteroidRepository(database)

    private val _navigateToDetailFragment = MutableLiveData<Asteroid?>()
    val navigateToDetailFragment: LiveData<Asteroid?>
        get() = _navigateToDetailFragment

    private var _asteroids = MutableLiveData<List<Asteroid>>()
    val asteroids: LiveData<List<Asteroid>>
        get() = _asteroids

    private val _pictureOfDay = MutableLiveData<PictureOfDay?>()
    val pictureOfDay: LiveData<PictureOfDay?>
        get() = _pictureOfDay

//    private val _displaySnackbarEvent = MutableLiveData<Boolean>()
//    val displaySnackbarEvent: LiveData<Boolean>
//        get() = _displaySnackbarEvent

    init {
        onViewWeekAsteroidsClicked()
        viewModelScope.launch {
            try {
                asteroidRepository.refreshAsteroids()
                refreshPictureOfDay()
            } catch (e: Exception) {
                println("Exception refreshing data: $e.message")
//                _displaySnackbarEvent.value = true
            }
//            val newpic = PictureOfDay(0,"","","")
//
//            insert(newpic)
        }
    }

    private suspend fun refreshPictureOfDay() {
       _pictureOfDay.value = getPictureOfDay()

    }

    //    private suspend fun insert(pictureOfDay: PictureOfDay) {
//        withContext(Dispatchers.IO) {
//            database.asteroidDao.insertPic(pictureOfDay)
//        }
//    }
    fun onAsteroidClicked(asteroid: Asteroid) {
        _navigateToDetailFragment.value = asteroid
    }

    fun doneNavigating() {
        _navigateToDetailFragment.value = null
    }

//    fun doneDisplayingSnackbar() {
//        _displaySnackbarEvent.value = false
//    }

    fun onViewWeekAsteroidsClicked() {
        viewModelScope.launch {
            database.asteroidDao.getAsteroidsByCloseApproachDate(getToday(), getSeventhDay())
                .collect { asteroids ->
                    _asteroids.value = asteroids
                }
        }
    }

    fun onTodayAsteroidsClicked() {
        viewModelScope.launch {
            database.asteroidDao.getAsteroidsByCloseApproachDate(getToday(), getToday())
                .collect { asteroids ->
                    _asteroids.value = asteroids
                }
        }
    }

    fun onSavedAsteroidsClicked() {
        viewModelScope.launch {
            database.asteroidDao.getAllAsteroids().collect { asteroids ->
                _asteroids.value = asteroids
            }
        }
    }

    private suspend fun getPictureOfDay(): PictureOfDay? {
        withContext(Dispatchers.IO) {
            val oldPic = PictureDayDao.get()
            try {
                val picFromApi= Network.service.getPictureOfDayAsync() // get the Picture from api
                if (picFromApi.mediaType == IMAGE_MEDIA_TYPE){
                    PictureDayDao.insertPic(picFromApi)
                }
            }catch (e: Exception){
                PictureDayDao.get(oldPic)
            }
        }
        return null
    }
}